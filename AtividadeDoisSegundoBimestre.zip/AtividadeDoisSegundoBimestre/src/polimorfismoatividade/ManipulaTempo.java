package polimorfismoatividade;

public class ManipulaTempo {

    public static void main(String[] args) {
        // Teste para a classe Tempo
        Tempo oTempo = new Tempo(1, 30, 45); // 1 hora, 30 minutos, 45 segundos
        dadosTempo(oTempo);

        // Teste para a classe Data
        Data oData = new Data(10, 5, 2024); // 10 de maio de 2024
        dadosData(oData);

        // Teste para a classe Horario
        Horario oHorario = new Horario(15, 45, 30); // 15:45:30
        dadosHorario(oHorario);
    }

    public static void dadosTempo(Tempo oTempo) {
        System.out.println("Tempo formatado: " + oTempo.toString());
        System.out.println("Tempo em segundos: " + oTempo.quantidade());
    }

    public static void dadosData(Data oData) {
        System.out.println("Data formatada: " + oData.toString());
        System.out.println("Data em segundos: " + oData.quantidade());
    }

    public static void dadosHorario(Horario oHorario) {
        System.out.println("Horário formatado: " + oHorario.toString());
        System.out.println("Horário em segundos: " + oHorario.quantidade());
    }
}