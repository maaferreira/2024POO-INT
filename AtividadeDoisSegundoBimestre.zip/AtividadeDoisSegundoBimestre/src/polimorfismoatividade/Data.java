package polimorfismoatividade;

public class Data {
    private int dia;
    private int mes;
    private int ano;

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", dia, mes, ano);
    }

    public int quantidade() {
        // Este método é ilustrativo; ele deve ser ajustado conforme a necessidade real.
        // Pode, por exemplo, retornar o número total de dias até essa data.
        return dia + mes * 30 + ano * 365;
    }
}
